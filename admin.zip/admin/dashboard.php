<?php
require_once '../auth.php'; // This line is crucial for security and must come first.

// --- Handle Save/Update/Delete Operations ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dataFile = '../data.json';
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Determine action from either POST data (for forms with files) or JSON input
    $action = $_POST['action'] ?? $input['action'] ?? '';

    $uploadDir = '../uploads/';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    function handleUpload($fileKey, $existingPath = '') {
        global $uploadDir;
        if (!isset($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] == UPLOAD_ERR_NO_FILE) {
            return ['success' => true, 'path_or_error' => $existingPath];
        }
        if ($_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
            switch ($_FILES[$fileKey]['error']) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    return ['success' => false, 'path_or_error' => 'File is too large.'];
                case UPLOAD_ERR_PARTIAL:
                    return ['success' => false, 'path_or_error' => 'File was only partially uploaded.'];
                default:
                    return ['success' => false, 'path_or_error' => 'An upload error occurred.'];
            }
        }
        $fileName = uniqid() . '-' . basename(preg_replace("/[^a-zA-Z0-9.\s-]/", "", $_FILES[$fileKey]['name']));
        $targetPath = $uploadDir . $fileName;
        if (move_uploaded_file($_FILES[$fileKey]['tmp_name'], $targetPath)) {
            return ['success' => true, 'path_or_error' => 'uploads/' . $fileName];
        } else {
            return ['success' => false, 'path_or_error' => 'Could not move uploaded file. Check permissions for "uploads" directory.'];
        }
    }

    function getYoutubeEmbedUrl($url) {
        $video_id = '';
        if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $matches)) {
            $video_id = $matches[1];
        } else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $matches)) {
            $video_id = $matches[1];
        } else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $matches)) {
            $video_id = $matches[1];
        }
        
        if ($video_id) {
            return 'https://www.youtube.com/embed/' . $video_id;
        }
        return '';
    }

    $json_data = file_get_contents($dataFile);
    $data = json_decode($json_data, true);
    if ($data === null) { // Handle JSON read error
        $data = ["articles" => [], "socialFeed" => [], "newsFlashes" => [], "advertisements" => [], "live_tv_video_id" => ""];
    }


    if ($action === 'save_article') {
        $articleData = $_POST;
        
        $mediaType = $articleData['mediaType'] ?? 'image';
        $mediaUrl = '';

        if ($mediaType === 'image') {
            $uploadResult = handleUpload('mediaFile', $articleData['existingMediaUrl'] ?? '');
            if (!$uploadResult['success']) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => $uploadResult['path_or_error']]);
                exit;
            }
            $mediaUrl = $uploadResult['path_or_error'];
        } elseif ($mediaType === 'video') {
            $videoUrlInput = $articleData['mediaUrlInput'] ?? '';
            $mediaUrl = getYoutubeEmbedUrl($videoUrlInput);
            if (empty($mediaUrl)) {
                 http_response_code(400);
                 echo json_encode(['status' => 'error', 'message' => 'Invalid YouTube URL provided. Please use a valid watch, share, or embed link.']);
                 exit;
            }
        }
        
        $content = $articleData['content'];
        $category = $articleData['category'];

        if ($category === 'Beeps' && !empty($articleData['summary'])) {
            $summaryPoints = explode("\n", trim($articleData['summary']));
            $summaryHtml = '<ul>';
            foreach ($summaryPoints as $point) {
                $trimmedPoint = trim($point);
                if (!empty($trimmedPoint)) {
                    $summaryHtml .= '<li>' . htmlspecialchars($trimmedPoint, ENT_QUOTES, 'UTF-8') . '</li>';
                }
            }
            $summaryHtml .= '</ul>';
            $content = $summaryHtml . $content;
        }

        $article = [
            'headline' => $articleData['headline'],
            'author' => $articleData['author'],
            'timestamp' => $articleData['timestamp'],
            'category' => $articleData['category'],
            'subCategory' => $articleData['subCategory'],
            'content' => $content,
            'mediaType' => $mediaType,
            'mediaUrl' => $mediaUrl,
            'redirectToHome' => isset($articleData['redirectToHome']) && $articleData['redirectToHome'] === 'true'
        ];
        
        $articleId = $articleData['id'] ?? null;
        $foundIndex = -1;

        if (!empty($articleId)) {
            foreach ($data['articles'] as $key => $value) {
                if ($value['id'] == $articleId) {
                    $foundIndex = $key;
                    break;
                }
            }
        }

        if ($foundIndex !== -1) {
            $article['id'] = (int)$articleId;
            $data['articles'][$foundIndex] = $article;
        } else {
            $new_id = !empty($data['articles']) ? max(array_column($data['articles'], 'id')) + 1 : 1;
            $article['id'] = $new_id;
            array_unshift($data['articles'], $article);
        }

    } 
    elseif ($action === 'delete_article') {
        $id = $input['id'];
        $data['articles'] = array_values(array_filter($data['articles'], function($article) use ($id) {
            return $article['id'] != $id;
        }));
    }
    elseif ($action === 'save_social') {
        $socialData = $_POST;
        
        $avatarPath = handleUpload('avatar', $socialData['existingAvatar'] ?? '')['path_or_error'];
        $imagePath = handleUpload('imageUrl', $socialData['existingImageUrl'] ?? '')['path_or_error'];

        $post = [
            'platform' => $socialData['platform'] ?? 'Unknown',
            'user' => $socialData['user'] ?? 'Unknown',
            'handle' => $socialData['handle'] ?? 'unknown',
            'timestamp' => $socialData['timestamp'] ?? '',
            'content' => $socialData['content'] ?? '',
            'url' => $socialData['url'] ?? '#',
            'avatar' => $avatarPath,
            'imageUrl' => $imagePath
        ];
        
        $postId = $socialData['id'] ?? null;
        $foundIndex = -1;
         if (!empty($postId)) {
            foreach ($data['socialFeed'] as $key => $value) {
                if ($value['id'] == $postId) {
                    $foundIndex = $key;
                    break;
                }
            }
        }
        
        if ($foundIndex !== -1) {
            $post['id'] = (int)$postId;
            $data['socialFeed'][$foundIndex] = $post;
        } else {
            $new_id = !empty($data['socialFeed']) ? max(array_column($data['socialFeed'], 'id')) + 1 : 1;
            $post['id'] = $new_id;
            $data['socialFeed'][] = $post;
        }
    }
    elseif ($action === 'delete_social') {
        $id = $input['id'];
        $data['socialFeed'] = array_values(array_filter($data['socialFeed'], function($post) use ($id) {
            return $post['id'] != $id;
        }));
    }
    elseif ($action === 'save_flashes') {
        $data['newsFlashes'] = $input['flashes'];
    }
    elseif ($action === 'save_ads') {
        $adsData = [
            'main_ad' => [],
            'left_sidebar_ad' => [],
            'right_sidebar_ad' => []
        ];

        // --- Main Ad ---
        $mainUploadResult = handleUpload('main_ad_image', $_POST['existing_main_ad_image_url']);
        $adsData['main_ad']['image_url'] = $mainUploadResult['path_or_error'];
        $adsData['main_ad']['redirect_url'] = $_POST['main_ad_redirect_url'] ?? '';

        // --- Left Sidebar Ad ---
        $leftUploadResult = handleUpload('left_sidebar_ad_image', $_POST['existing_left_sidebar_ad_image_url']);
        $adsData['left_sidebar_ad']['image_url'] = $leftUploadResult['path_or_error'];
        $adsData['left_sidebar_ad']['redirect_url'] = $_POST['left_sidebar_ad_redirect_url'] ?? '';

        // --- Right Sidebar Ad ---
        $rightUploadResult = handleUpload('right_sidebar_ad_image', $_POST['existing_right_sidebar_ad_image_url']);
        $adsData['right_sidebar_ad']['image_url'] = $rightUploadResult['path_or_error'];
        $adsData['right_sidebar_ad']['redirect_url'] = $_POST['right_sidebar_ad_redirect_url'] ?? '';

        $data['advertisements'] = $adsData;
    }
     elseif ($action === 'save_livetv') {
        $data['live_tv_video_id'] = $input['video_id'];
    }

    // Save data back to file
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'data' => $data]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .ck-editor__editable_inline { min-height: 250px; }
        .spinner { display: inline-block; border: 2px solid #f3f3f3; border-top: 2px solid #3498db; border-radius: 50%; width: 16px; height: 16px; animation: spin 1s linear infinite; margin-left: 8px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-800 text-white flex flex-col">
            <div class="p-4 text-2xl font-bold border-b border-gray-700">UTC News Admin</div>
            <nav class="flex-1 p-4 space-y-2">
                <a href="#articles" class="nav-link active"><i data-lucide="newspaper" class="icon"></i> Articles</a>
                <a href="#social" class="nav-link"><i data-lucide="users" class="icon"></i> Social Feed</a>
                <a href="#flashes" class="nav-link"><i data-lucide="zap" class="icon"></i> News Flashes</a>
                <a href="#ads" class="nav-link"><i data-lucide="megaphone" class="icon"></i> Advertisements</a>
                <a href="#livetv" class="nav-link"><i data-lucide="tv" class="icon"></i> Live TV</a>
            </nav>
            <div class="p-4 border-t border-gray-700">
                <a href="logout.php" class="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-2 px-4 rounded-full w-full text-center block transition-colors">Logout</a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-8 overflow-y-auto">
            <section id="articles" class="content-section">
                <h1 class="text-3xl font-bold mb-6">Manage Articles</h1>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <button id="add-article-btn" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 mb-4">Add New Article</button>
                    <div id="articles-list" class="space-y-4"></div>
                </div>
            </section>
            <section id="social" class="content-section hidden">
                <h1 class="text-3xl font-bold mb-6">Manage Social Feed</h1>
                 <div class="bg-white p-6 rounded-lg shadow-lg">
                    <button id="add-social-btn" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 mb-4">Add New Social Post</button>
                    <div id="social-feed-list" class="space-y-4"></div>
                </div>
            </section>
            <section id="flashes" class="content-section hidden">
                 <h1 class="text-3xl font-bold mb-6">Manage News Flashes</h1>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <form id="flashes-form">
                        <label for="news-flashes-textarea" class="block text-gray-700 font-bold mb-2">News Flash Items (One per line):</label>
                        <textarea id="news-flashes-textarea" class="w-full h-40 p-2 border rounded-lg" placeholder="Enter each news flash on a new line."></textarea>
                        <button type="submit" class="mt-4 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 flex items-center">
                            <span>Save Flashes</span> <span class="spinner-container ml-2"></span>
                        </button>
                    </form>
                </div>
            </section>
            <section id="ads" class="content-section hidden">
                <h1 class="text-3xl font-bold mb-6">Manage Advertisements</h1>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <form id="ads-form" class="space-y-8">
                        <!-- Main Ad Banner -->
                        <div>
                            <h2 class="text-xl font-semibold border-b pb-2 mb-4">Main Ad Banner (Recommended: 1200x200)</h2>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                                <div>
                                    <label for="main_ad_redirect_url" class="block text-gray-700 font-bold mb-2">Redirect Link (Optional)</label>
                                    <input type="url" id="main_ad_redirect_url" name="main_ad_redirect_url" class="w-full p-2 border rounded-lg" placeholder="https://example.com/product-page">
                                    
                                    <label for="main_ad_image" class="block text-gray-700 font-bold mb-2 mt-4">Upload Image</label>
                                    <input type="file" id="main_ad_image" name="main_ad_image" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept="image/*">
                                    <input type="hidden" id="existing_main_ad_image_url" name="existing_main_ad_image_url">
                                </div>
                                <div class="text-center">
                                    <p class="text-sm font-medium text-gray-500 mb-2">Live Preview</p>
                                    <img id="main_ad_preview" src="https://placehold.co/400x100/eee/ccc?text=No+Ad" alt="Main Ad Preview" class="w-full h-auto object-contain rounded-lg border p-2 bg-gray-50 max-h-40">
                                </div>
                            </div>
                        </div>

                        <!-- Left Sidebar Ad -->
                        <div>
                            <h2 class="text-xl font-semibold border-b pb-2 mb-4">Left Sidebar Ad (Recommended: 300x600)</h2>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                                <div>
                                    <label for="left_sidebar_ad_redirect_url" class="block text-gray-700 font-bold mb-2">Redirect Link (Optional)</label>
                                    <input type="url" id="left_sidebar_ad_redirect_url" name="left_sidebar_ad_redirect_url" class="w-full p-2 border rounded-lg" placeholder="https://example.com/product-page">
                                    
                                    <label for="left_sidebar_ad_image" class="block text-gray-700 font-bold mb-2 mt-4">Upload Image</label>
                                    <input type="file" id="left_sidebar_ad_image" name="left_sidebar_ad_image" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept="image/*">
                                    <input type="hidden" id="existing_left_sidebar_ad_image_url" name="existing_left_sidebar_ad_image_url">
                                </div>
                                <div class="text-center">
                                    <p class="text-sm font-medium text-gray-500 mb-2">Live Preview</p>
                                    <img id="left_sidebar_ad_preview" src="https://placehold.co/300x600/eee/ccc?text=No+Ad" alt="Left Sidebar Ad Preview" class="w-full h-auto object-contain rounded-lg border p-2 bg-gray-50 max-h-60">
                                </div>
                            </div>
                        </div>

                        <!-- Right Sidebar Ad -->
                        <div>
                            <h2 class="text-xl font-semibold border-b pb-2 mb-4">Right Sidebar Ad (Recommended: 300x600)</h2>
                             <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                                <div>
                                    <label for="right_sidebar_ad_redirect_url" class="block text-gray-700 font-bold mb-2">Redirect Link (Optional)</label>
                                    <input type="url" id="right_sidebar_ad_redirect_url" name="right_sidebar_ad_redirect_url" class="w-full p-2 border rounded-lg" placeholder="https://example.com/product-page">
                                    
                                    <label for="right_sidebar_ad_image" class="block text-gray-700 font-bold mb-2 mt-4">Upload Image</label>
                                    <input type="file" id="right_sidebar_ad_image" name="right_sidebar_ad_image" class="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" accept="image/*">
                                    <input type="hidden" id="existing_right_sidebar_ad_image_url" name="existing_right_sidebar_ad_image_url">
                                </div>
                                <div class="text-center">
                                    <p class="text-sm font-medium text-gray-500 mb-2">Live Preview</p>
                                    <img id="right_sidebar_ad_preview" src="https://placehold.co/300x600/eee/ccc?text=No+Ad" alt="Right Sidebar Ad Preview" class="w-full h-auto object-contain rounded-lg border p-2 bg-gray-50 max-h-60">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="mt-4 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 flex items-center">
                            <span>Save Advertisements</span> <span class="spinner-container ml-2"></span>
                        </button>
                    </form>
                </div>
            </section>
            <section id="livetv" class="content-section hidden">
                <h1 class="text-3xl font-bold mb-6">Manage Live TV Stream</h1>
                <div class="bg-white p-6 rounded-lg shadow-lg">
                    <form id="livetv-form" class="space-y-4">
                        <div>
                            <label for="livetv_video_id" class="block text-gray-700 font-bold mb-2">YouTube Video ID:</label>
                            <input type="text" id="livetv_video_id" name="livetv_video_id" class="w-full p-2 border rounded-lg" placeholder="e.g., h-4B0Kz-G54">
                             <p class="text-sm text-gray-500 mt-1">Enter only the ID from the YouTube URL. Example: For `https://www.youtube.com/watch?v=h-4B0Kz-G54`, the ID is `h-4B0Kz-G54`.</p>
                        </div>
                        <button type="submit" class="mt-4 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 flex items-center">
                            <span>Save Video ID</span> <span class="spinner-container ml-2"></span>
                        </button>
                    </form>
                </div>
            </section>
        </main>
    </div>

    <!-- Article Modal -->
    <div id="article-modal" class="modal-container hidden">
        <div class="modal-content">
            <h2 id="modal-title" class="text-2xl font-bold mb-4">Add New Article</h2>
            <form id="article-form">
                <input type="hidden" id="article-id" name="id">
                <input type="hidden" id="existingMediaUrl" name="existingMediaUrl">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                     <input type="text" id="article-headline" name="headline" placeholder="Headline" class="p-2 border rounded-lg" required>
                     <input type="text" id="article-author" name="author" placeholder="Author" class="p-2 border rounded-lg" required>
                     <input type="datetime-local" id="article-timestamp" name="timestamp" placeholder="Timestamp" class="p-2 border rounded-lg" required>
                     <select id="article-category" name="category" class="p-2 border rounded-lg" required>
                        <option value="" disabled selected>Select a Category</option>
                        <!-- Options populated by script.js -->
                     </select>
                     <select id="article-subcategory" name="subCategory" class="p-2 border rounded-lg hidden">
                        <!-- Options populated by script.js -->
                     </select>
                </div>
                
                <div id="beeps-summary-container" class="mb-4 hidden">
                    <label for="article-summary" class="block text-sm font-medium text-gray-700 mb-1">Beeps Summary Points</label>
                    <textarea id="article-summary" name="summary" class="w-full h-24 p-2 border rounded-lg" placeholder="Enter each summary point on a new line."></textarea>
                    <p class="text-xs text-gray-500 mt-1">These points will be displayed as a bulleted list on the 'Beeps' card.</p>
                </div>

                <div id="beeps-redirect-container" class="mb-4 hidden">
                    <label class="flex items-center">
                        <input type="checkbox" id="article-redirect" name="redirectToHome" value="true" class="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                        <span class="ml-2 text-gray-700">Redirect "Read More" to Home Page</span>
                    </label>
                    <p class="text-xs text-gray-500 mt-1">If checked, the 'Read More' button on the Beeps card will link to the main home page instead of the article detail page.</p>
                </div>

                 <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Media Type</label>
                    <div class="flex items-center space-x-4">
                        <label class="flex items-center">
                            <input type="radio" id="media-type-image" name="mediaType" value="image" class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" checked>
                            <span class="ml-2 text-gray-700">Image Upload</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" id="media-type-video" name="mediaType" value="video" class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500">
                            <span class="ml-2 text-gray-700">YouTube Video</span>
                        </label>
                    </div>
                 </div>

                 <div id="image-upload-container" class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Upload Image</label>
                    <input type="file" id="article-image-upload" name="mediaFile" class="p-2 border rounded-lg w-full" accept="image/*">
                    <div id="article-image-preview-container" class="relative w-24 mt-2" style="display: none;">
                        <img id="article-image-preview" class="h-20 w-24 object-cover rounded-lg" src="" alt="Image Preview">
                        <button type="button" id="remove-article-image-btn" class="absolute top-0 right-0 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-lg font-bold -mt-2 -mr-2 hover:bg-red-700 focus:outline-none" title="Remove Image">&times;</button>
                    </div>
                </div>
                <div id="video-url-container" class="mb-4 hidden">
                    <label for="video-url-input" class="block text-sm font-medium text-gray-700 mb-1">YouTube Video URL</label>
                    <input type="url" id="video-url-input" name="mediaUrlInput" class="p-2 border rounded-lg w-full" placeholder="e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Content</label>
                    <textarea id="article-content" name="content" class="w-full h-40 p-2 border rounded-lg"></textarea>
                </div>
                <div class="mt-6 flex justify-end space-x-4">
                    <button type="button" id="cancel-article" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">Cancel</button>
                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center">
                        <span>Save Article</span> <span class="spinner-container ml-2"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="social-modal" class="modal-container hidden">
        <div class="modal-content">
            <h2 id="social-modal-title" class="text-2xl font-bold mb-4">Add New Social Post</h2>
            <form id="social-form" class="space-y-4">
                <input type="hidden" id="social-id" name="id">
                <input type="hidden" id="existingAvatar" name="existingAvatar">
                <input type="hidden" id="existingImageUrl" name="existingImageUrl">
                <select id="social-platform" name="platform" class="w-full p-2 border rounded-lg" required>
                    <option value="Twitter">Twitter</option>
                    <option value="Facebook">Facebook</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                </select>
                <input type="text" id="social-user" name="user" placeholder="Username (e.g., UTC NEWS)" class="w-full p-2 border rounded-lg" required>
                <input type="text" id="social-handle" name="handle" placeholder="Handle (e.g., utcnews)" class="w-full p-2 border rounded-lg" required>
                <textarea id="social-content" name="content" placeholder="Post content" class="w-full h-24 p-2 border rounded-lg" required></textarea>
                <input type="datetime-local" id="social-timestamp" name="timestamp" class="w-full p-2 border rounded-lg" required>
                <input type="url" id="social-url" name="url" placeholder="Post URL" class="w-full p-2 border rounded-lg" required>
                 <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Avatar Image</label>
                        <input type="file" id="social-avatar-upload" name="avatar" class="p-2 border rounded-lg w-full" accept="image/*">
                        <div id="social-avatar-preview-container" class="relative w-24 mt-2" style="display: none;">
                           <img id="social-avatar-preview" class="h-20 w-24 object-cover rounded-lg" src="" alt="Avatar Preview">
                           <button type="button" id="remove-social-avatar-btn" class="absolute top-0 right-0 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-lg font-bold -mt-2 -mr-2 hover:bg-red-700 focus:outline-none" title="Remove Avatar">&times;</button>
                        </div>
                    </div>
                     <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Post Image (Optional)</label>
                        <input type="file" id="social-image-upload" name="imageUrl" class="p-2 border rounded-lg w-full" accept="image/*">
                        <div id="social-image-preview-container" class="relative w-24 mt-2" style="display: none;">
                            <img id="social-image-preview" class="h-20 w-24 object-cover rounded-lg" src="" alt="Image Preview">
                            <button type="button" id="remove-social-image-btn" class="absolute top-0 right-0 bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-lg font-bold -mt-2 -mr-2 hover:bg-red-700 focus:outline-none" title="Remove Image">&times;</button>
                        </div>
                    </div>
                </div>
                <div class="mt-6 flex justify-end space-x-4">
                    <button type="button" id="cancel-social" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">Cancel</button>
                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center">
                        <span>Save Post</span><span class="spinner-container ml-2"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            lucide.createIcons();
        });
    </script>
</body>
</html>
