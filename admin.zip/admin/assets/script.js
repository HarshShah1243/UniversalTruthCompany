document.addEventListener('DOMContentLoaded', () => {
    // --- State ---
    let siteData = { articles: [], socialFeed: [], newsFlashes: [], advertisements: {}, live_tv_video_id: '' };
    let ckEditorInstance;

    // --- Navigation Configuration for Categories & Sub-categories ---
    const navConfig = [
        { name: "LiveTV", subCategories: ["यूटीसी न्यूज़ लाइव", "प्रॉफिट टीवी", "मूवीज़ टीवी", "वडोदरा लाइव"] },
        { name: "Latest", subCategories: [] },
        { name: "India", subCategories: ["All India News", "Global", "Expat", "South"] },
        { name: "World", subCategories: [] },
        { name: "Sports", subCategories: ["Cricket", "Football"] },
        { name: "Opinion", subCategories: [] },
        { name: "Cities", subCategories: ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar"] },
        { name: "Beeps", subCategories: [] },
        { name: "Education", subCategories: [] },
        { name: "Videos", subCategories: [] },
        { name: "Auto", subCategories: [] },
        { name: "Entertainment", subCategories: [] },
        { name: "Lifestyle", subCategories: [] },
        { name: "Podcast", subCategories: [] },
        { name: "Weather", subCategories: [] },
        { name: "Offbeat", subCategories: [] },
        { name: "Science", subCategories: [] },
        { name: "Health", subCategories: [] },
        { name: "Pictures", subCategories: [] },
        { name: "Tech", subCategories: [] },
        { name: "Business", subCategories: [] }
    ];

    // --- DOM Elements ---
    const navLinks = document.querySelectorAll('.nav-link');
    const contentSections = document.querySelectorAll('.content-section');
    const articlesList = document.getElementById('articles-list');
    const addArticleBtn = document.getElementById('add-article-btn');
    const articleModal = document.getElementById('article-modal');
    const articleForm = document.getElementById('article-form');
    const cancelArticleBtn = document.getElementById('cancel-article');
    const socialFeedList = document.getElementById('social-feed-list');
    const addSocialBtn = document.getElementById('add-social-btn');
    const socialModal = document.getElementById('social-modal');
    const socialForm = document.getElementById('social-form');
    const cancelSocialBtn = document.getElementById('cancel-social');
    const flashesForm = document.getElementById('flashes-form');
    const flashesTextarea = document.getElementById('news-flashes-textarea');
    const adsForm = document.getElementById('ads-form');
    const liveTvForm = document.getElementById('livetv-form');
    const liveTvInput = document.getElementById('livetv_video_id');
    const articleImagePreview = document.getElementById('article-image-preview');
    const socialAvatarPreview = document.getElementById('social-avatar-preview');
    const socialImagePreview = document.getElementById('social-image-preview');
    const mediaTypeImageRadio = document.getElementById('media-type-image');
    const mediaTypeVideoRadio = document.getElementById('media-type-video');
    const imageUploadContainer = document.getElementById('image-upload-container');
    const videoUrlContainer = document.getElementById('video-url-container');
    const videoUrlInput = document.getElementById('video-url-input');
    const beepsSummaryContainer = document.getElementById('beeps-summary-container');
    const beepsRedirectContainer = document.getElementById('beeps-redirect-container');
    const articleCategorySelect = document.getElementById('article-category');
    const articleSubCategorySelect = document.getElementById('article-subcategory');
    const articleImagePreviewContainer = document.getElementById('article-image-preview-container');
    const removeArticleImageBtn = document.getElementById('remove-article-image-btn');
    const socialImagePreviewContainer = document.getElementById('social-image-preview-container');
    const removeSocialImageBtn = document.getElementById('remove-social-image-btn');
    const socialAvatarPreviewContainer = document.getElementById('social-avatar-preview-container');
    const removeSocialAvatarBtn = document.getElementById('remove-social-avatar-btn');


    // --- Utility Functions ---
    const openModal = (modal) => modal.classList.remove('hidden');
    const closeModal = (modal) => modal.classList.add('hidden');

    const showSpinner = (button) => {
        if (!button) return;
        button.disabled = true;
        const spinnerContainer = button.querySelector('.spinner-container');
        if (spinnerContainer) {
            spinnerContainer.innerHTML = '<div class="spinner"></div>';
        }
    };

    const hideSpinner = (button) => {
        if (!button) return;
        button.disabled = false;
        const spinnerContainer = button.querySelector('.spinner-container');
        if (spinnerContainer) {
            spinnerContainer.innerHTML = '';
        }
    };

    const setupImagePreview = (fileInputId, previewImgId, previewContainerId) => {
        const fileInput = document.getElementById(fileInputId);
        const previewImg = document.getElementById(previewImgId);
        const previewContainer = document.getElementById(previewContainerId);
        if (!fileInput || !previewImg || !previewContainer) return;

        fileInput.addEventListener('change', () => {
            const file = fileInput.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    previewImg.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
    };

    setupImagePreview('article-image-upload', 'article-image-preview', 'article-image-preview-container');
    setupImagePreview('social-avatar-upload', 'social-avatar-preview', 'social-avatar-preview-container');
    setupImagePreview('social-image-upload', 'social-image-preview', 'social-image-preview-container');

    // --- Init CKEditor ---
    if (document.querySelector('#article-content')) {
        ClassicEditor
            .create(document.querySelector('#article-content'))
            .then(editor => {
                ckEditorInstance = editor;
            })
            .catch(error => {
                console.error('Error initializing CKEditor:', error);
            });
    }

    // --- API Calls ---
    const fetchData = async () => {
        try {
            const response = await fetch('../api.php');
            if (!response.ok) throw new Error(`Network response was not ok (${response.status})`);
            siteData = await response.json();
            renderAll();
        } catch (error) {
            console.error('Failed to fetch data:', error);
            alert('Could not load site data. Check the developer console for more details.');
        }
    };

    const saveData = async (action, body, button) => {
        showSpinner(button);

        let fetchOptions = {
            method: 'POST',
            body: body,
        };

        if (!(body instanceof FormData)) {
            fetchOptions.headers = {
                'Content-Type': 'application/json'
            };
        }

        try {
            const response = await fetch('dashboard.php', fetchOptions);
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || `Server error: ${response.status}`);
            }

            if (result.status === 'success') {
                siteData = result.data;
                renderAll();
                return true;
            } else {
                throw new Error(result.message || 'An unknown error occurred on the server.');
            }
        } catch (error) {
            console.error('Failed to save data:', error);
            alert(`Error: ${error.message}`);
            return false;
        } finally {
            hideSpinner(button);
        }
    };


    // --- Render Functions ---
    const renderAll = () => {
        renderArticles();
        renderSocialFeed();
        renderFlashes();
        renderAds();
        renderLiveTv();
        lucide.createIcons();
    };

    const renderArticles = () => {
        articlesList.innerHTML = '';
        if (!siteData.articles || siteData.articles.length === 0) {
            articlesList.innerHTML = '<p class="text-gray-500">No articles found. Add one to get started!</p>';
            return;
        }
        siteData.articles.forEach(article => {
            const articleEl = document.createElement('div');
            articleEl.className = 'item-card';

            let mediaPreviewHTML = '';
            if (article.mediaType === 'video') {
                mediaPreviewHTML = `<div class="w-24 h-16 bg-black rounded-md flex-shrink-0 flex items-center justify-center"><svg class="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>`;
            } else {
                mediaPreviewHTML = `<img src="../${article.mediaUrl || 'https://placehold.co/100x60/eee/ccc?text=No+Image'}" alt="Article Image" class="w-24 h-16 object-cover rounded-md flex-shrink-0" onerror="this.src='https://placehold.co/100x60/eee/ccc?text=Error';">`;
            }

            articleEl.innerHTML = `
                <div class="flex items-center space-x-4 min-w-0">
                    ${mediaPreviewHTML}
                    <div class="min-w-0">
                        <h3 class="truncate font-bold">${article.headline || 'Untitled'}</h3>
                        <p class="text-sm text-gray-500">${article.category || 'N/A'} ${article.subCategory ? `> ${article.subCategory}` : ''} | By ${article.author || 'N/A'}</p>
                    </div>
                </div>
                <div class="space-x-2 flex-shrink-0 ml-4">
                    <button class="edit-article-btn bg-yellow-500 text-white px-3 py-1 rounded-md text-sm hover:bg-yellow-600" data-id="${article.id}">Edit</button>
                    <button class="delete-article-btn bg-red-500 text-white px-3 py-1 rounded-md text-sm hover:bg-red-600" data-id="${article.id}">Delete</button>
                </div>
            `;
            articlesList.appendChild(articleEl);
        });
    };

    const renderSocialFeed = () => {
        socialFeedList.innerHTML = '';
        if (!siteData.socialFeed || siteData.socialFeed.length === 0) {
            socialFeedList.innerHTML = '<p class="text-gray-500">No social posts found.</p>';
            return;
        }
        siteData.socialFeed.forEach(post => {
            const postEl = document.createElement('div');
            postEl.className = 'item-card';
            postEl.innerHTML = `
                <div class="flex items-center space-x-4 min-w-0">
                    <img src="../${post.avatar || 'https://placehold.co/60x60/eee/ccc?text=No+Avatar'}" alt="Avatar" class="w-12 h-12 object-cover rounded-full flex-shrink-0" onerror="this.src='https://placehold.co/60x60/eee/ccc?text=Error';">
                    <div class="min-w-0">
                        <h3 class="font-bold">${post.platform}: @${post.handle}</h3>
                        <p class="truncate text-sm text-gray-500">${post.content}</p>
                    </div>
                </div>
                <div class="space-x-2 flex-shrink-0 ml-4">
                    <button class="edit-social-btn bg-yellow-500 text-white px-3 py-1 rounded-md text-sm hover:bg-yellow-600" data-id="${post.id}">Edit</button>
                    <button class="delete-social-btn bg-red-500 text-white px-3 py-1 rounded-md text-sm hover:bg-red-600" data-id="${post.id}">Delete</button>
                </div>
            `;
            socialFeedList.appendChild(postEl);
        });
    };

    const renderFlashes = () => { flashesTextarea.value = (siteData.newsFlashes || []).join('\n'); };

    const renderAds = () => {
        const ads = siteData.advertisements || {};
        const placeholderBase = 'https://placehold.co/';
        const defaultMain = placeholderBase + '400x100/eee/ccc?text=No+Ad';
        const defaultSidebar = placeholderBase + '300x600/eee/ccc?text=No+Ad';

        const getAdImageUrl = (url) => {
            if (!url) return '';
            if (url.startsWith('http')) return url;
            return `../${url}`;
        };

        // Main Ad
        const mainAd = ads.main_ad || {};
        document.getElementById('main_ad_redirect_url').value = mainAd.redirect_url || '';
        document.getElementById('existing_main_ad_image_url').value = mainAd.image_url || '';
        document.getElementById('main_ad_preview').src = mainAd.image_url ? getAdImageUrl(mainAd.image_url) : defaultMain;

        // Left Sidebar Ad
        const leftAd = ads.left_sidebar_ad || {};
        document.getElementById('left_sidebar_ad_redirect_url').value = leftAd.redirect_url || '';
        document.getElementById('existing_left_sidebar_ad_image_url').value = leftAd.image_url || '';
        document.getElementById('left_sidebar_ad_preview').src = leftAd.image_url ? getAdImageUrl(leftAd.image_url) : defaultSidebar;

        // Right Sidebar Ad
        const rightAd = ads.right_sidebar_ad || {};
        document.getElementById('right_sidebar_ad_redirect_url').value = rightAd.redirect_url || '';
        document.getElementById('existing_right_sidebar_ad_image_url').value = rightAd.image_url || '';
        document.getElementById('right_sidebar_ad_preview').src = rightAd.image_url ? getAdImageUrl(rightAd.image_url) : defaultSidebar;

        // Reset file inputs
        document.getElementById('main_ad_image').value = '';
        document.getElementById('left_sidebar_ad_image').value = '';
        document.getElementById('right_sidebar_ad_image').value = '';
    };

    const renderLiveTv = () => { liveTvInput.value = siteData.live_tv_video_id || ''; };

    // --- Category Management ---
    const populateCategories = () => {
        articleCategorySelect.innerHTML = '<option value="" disabled selected>Select a Category</option>';
        navConfig.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.name;
            option.textContent = cat.name;
            articleCategorySelect.appendChild(option);
        });
    };

    const updateSubcategories = (selectedCategory, subCategoryToSelect = null) => {
        const categoryConfig = navConfig.find(cat => cat.name === selectedCategory);
        articleSubCategorySelect.innerHTML = '';

        if (categoryConfig && categoryConfig.subCategories.length > 0) {
            articleSubCategorySelect.classList.remove('hidden');

            const defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.textContent = "Select a Sub-category";
            articleSubCategorySelect.appendChild(defaultOption);

            categoryConfig.subCategories.forEach(sub => {
                const option = document.createElement('option');
                option.value = sub;
                option.textContent = sub;
                articleSubCategorySelect.appendChild(option);
            });

            if (subCategoryToSelect) {
                articleSubCategorySelect.value = subCategoryToSelect;
            }
        } else {
            articleSubCategorySelect.classList.add('hidden');
            articleSubCategorySelect.value = '';
        }
    };


    // --- Event Handlers ---
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            contentSections.forEach(s => s.classList.add('hidden'));
            document.querySelector(link.getAttribute('href')).classList.remove('hidden');
        });
    });

    articleCategorySelect.addEventListener('change', () => {
        updateSubcategories(articleCategorySelect.value);
        if (articleCategorySelect.value === 'Beeps') {
            beepsSummaryContainer.classList.remove('hidden');
            beepsRedirectContainer.classList.remove('hidden');
        } else {
            beepsSummaryContainer.classList.add('hidden');
            beepsRedirectContainer.classList.add('hidden');
        }
    });

    const handleMediaTypeChange = () => {
        if (mediaTypeImageRadio.checked) {
            imageUploadContainer.classList.remove('hidden');
            videoUrlContainer.classList.add('hidden');
        } else {
            imageUploadContainer.classList.add('hidden');
            videoUrlContainer.classList.remove('hidden');
        }
    };
    mediaTypeImageRadio.addEventListener('change', handleMediaTypeChange);
    mediaTypeVideoRadio.addEventListener('change', handleMediaTypeChange);

    addArticleBtn.addEventListener('click', () => {
        articleForm.reset();
        if (ckEditorInstance) ckEditorInstance.setData('');
        document.getElementById('modal-title').textContent = 'Add New Article';
        document.getElementById('article-id').value = '';
        articleImagePreview.src = '';
        articleImagePreviewContainer.style.display = 'none';
        mediaTypeImageRadio.checked = true;
        handleMediaTypeChange();
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        document.getElementById('article-timestamp').value = now.toISOString().slice(0, 16);

        beepsSummaryContainer.classList.add('hidden');
        beepsRedirectContainer.classList.add('hidden');
        document.getElementById('article-summary').value = '';
        document.getElementById('article-redirect').checked = false;

        articleCategorySelect.value = ""; // Reset category
        updateSubcategories(""); // This will hide subcategories

        openModal(articleModal);
    });
    cancelArticleBtn.addEventListener('click', () => closeModal(articleModal));

    articleForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(articleForm);
        if (ckEditorInstance) formData.set('content', ckEditorInstance.getData());
        formData.append('action', 'save_article');
        const success = await saveData('save_article', formData, e.submitter);
        if (success) closeModal(articleModal);
    });

    articlesList.addEventListener('click', e => {
        const editBtn = e.target.closest('.edit-article-btn');
        if (editBtn) {
            const id = editBtn.dataset.id;
            const article = siteData.articles.find(a => a.id == id);
            if (article) {
                document.getElementById('modal-title').textContent = 'Edit Article';
                articleForm.elements.id.value = article.id;
                articleForm.elements.headline.value = article.headline;
                articleForm.elements.author.value = article.author;
                articleForm.elements.timestamp.value = article.timestamp;
                articleForm.elements.category.value = article.category;

                updateSubcategories(article.category, article.subCategory);

                const summaryTextarea = document.getElementById('article-summary');
                const redirectCheckbox = document.getElementById('article-redirect');

                if (article.category === 'Beeps') {
                    beepsSummaryContainer.classList.remove('hidden');
                    beepsRedirectContainer.classList.remove('hidden');
                    redirectCheckbox.checked = !!article.redirectToHome;

                    const content = article.content || '';
                    const summaryMatch = content.match(/<ul[\s\S]*?<\/ul>/);
                    let mainContent = content;
                    let summaryPoints = '';

                    if (summaryMatch) {
                        const summaryHtml = summaryMatch[0];
                        mainContent = content.replace(summaryHtml, '').trim();

                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = summaryHtml;
                        const listItems = tempDiv.querySelectorAll('li');
                        summaryPoints = Array.from(listItems).map(li => li.textContent).join('\n');
                    }

                    summaryTextarea.value = summaryPoints;
                    if (ckEditorInstance) ckEditorInstance.setData(mainContent);

                } else {
                    beepsSummaryContainer.classList.add('hidden');
                    beepsRedirectContainer.classList.add('hidden');
                    summaryTextarea.value = '';
                    redirectCheckbox.checked = false;
                    if (ckEditorInstance) ckEditorInstance.setData(article.content || '');
                }

                articleForm.elements.existingMediaUrl.value = article.mediaUrl || '';
                if (article.mediaType === 'video') {
                    mediaTypeVideoRadio.checked = true;
                    videoUrlInput.value = article.mediaUrl ? `https://www.youtube.com/watch?v=${article.mediaUrl.split('/').pop()}` : '';
                    articleImagePreviewContainer.style.display = 'none';
                } else {
                    mediaTypeImageRadio.checked = true;
                    videoUrlInput.value = '';
                    if (article.mediaUrl) {
                        articleImagePreview.src = `../${article.mediaUrl}`;
                        articleImagePreviewContainer.style.display = 'block';
                    } else {
                        articleImagePreview.src = '';
                        articleImagePreviewContainer.style.display = 'none';
                    }
                }
                handleMediaTypeChange();

                openModal(articleModal);
            }
        }

        const deleteBtn = e.target.closest('.delete-article-btn');
        if (deleteBtn) {
            if (confirm('Are you sure you want to delete this article?')) {
                const id = deleteBtn.dataset.id;
                saveData('delete_article', JSON.stringify({ action: 'delete_article', id: id }), deleteBtn);
            }
        }
    });

    addSocialBtn.addEventListener('click', () => {
        socialForm.reset();
        document.getElementById('social-modal-title').textContent = 'Add New Social Post';
        document.getElementById('social-id').value = '';
        socialAvatarPreview.src = '';
        socialAvatarPreviewContainer.style.display = 'none';
        socialImagePreview.src = '';
        socialImagePreviewContainer.style.display = 'none';

        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        document.getElementById('social-timestamp').value = now.toISOString().slice(0, 16);

        openModal(socialModal);
    });
    cancelSocialBtn.addEventListener('click', () => closeModal(socialModal));

    socialForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(socialForm);
        formData.append('action', 'save_social');
        const success = await saveData('save_social', formData, e.submitter);
        if (success) closeModal(socialModal);
    });

    socialFeedList.addEventListener('click', e => {
        const editBtn = e.target.closest('.edit-social-btn');
        if (editBtn) {
            const post = siteData.socialFeed.find(p => p.id == editBtn.dataset.id);
            if (post) {
                document.getElementById('social-modal-title').textContent = 'Edit Social Post';
                socialForm.elements.id.value = post.id;
                socialForm.elements.platform.value = post.platform;
                socialForm.elements.user.value = post.user;
                socialForm.elements.handle.value = post.handle;
                socialForm.elements.content.value = post.content;
                socialForm.elements.timestamp.value = post.timestamp;
                socialForm.elements.url.value = post.url;

                socialForm.elements.existingAvatar.value = post.avatar || '';
                if (post.avatar) {
                    socialAvatarPreview.src = `../${post.avatar}`;
                    socialAvatarPreviewContainer.style.display = 'block';
                } else {
                    socialAvatarPreview.src = '';
                    socialAvatarPreviewContainer.style.display = 'none';
                }

                socialForm.elements.existingImageUrl.value = post.imageUrl || '';
                if (post.imageUrl) {
                    socialImagePreview.src = `../${post.imageUrl}`;
                    socialImagePreviewContainer.style.display = 'block';
                } else {
                    socialImagePreview.src = '';
                    socialImagePreviewContainer.style.display = 'none';
                }
                openModal(socialModal);
            }
        }

        const deleteBtn = e.target.closest('.delete-social-btn');
        if (deleteBtn) {
            if (confirm('Are you sure you want to delete this social post?')) {
                saveData('delete_social', JSON.stringify({ action: 'delete_social', id: deleteBtn.dataset.id }), deleteBtn);
            }
        }
    });

    removeArticleImageBtn.addEventListener('click', () => {
        document.getElementById('article-image-upload').value = '';
        document.getElementById('existingMediaUrl').value = '';
        articleImagePreview.src = '';
        articleImagePreviewContainer.style.display = 'none';
    });

    removeSocialImageBtn.addEventListener('click', () => {
        document.getElementById('social-image-upload').value = '';
        document.getElementById('existingImageUrl').value = '';
        socialImagePreview.src = '';
        socialImagePreviewContainer.style.display = 'none';
    });

    removeSocialAvatarBtn.addEventListener('click', () => {
        document.getElementById('social-avatar-upload').value = '';
        document.getElementById('existingAvatar').value = '';
        socialAvatarPreview.src = '';
        socialAvatarPreviewContainer.style.display = 'none';
    });

    const simpleFormHandler = async (e, action) => {
        e.preventDefault();
        let payload;
        if (action === 'save_flashes') {
            payload = { flashes: flashesTextarea.value.split('\n').map(l => l.trim()).filter(Boolean) };
        } else if (action === 'save_livetv') {
            payload = { video_id: liveTvInput.value.trim() };
        }

        if (payload) {
            payload.action = action;
            const success = await saveData(action, JSON.stringify(payload), e.submitter);
            if (success) alert(`${action.replace('save_', '').replace('_', ' ')} saved successfully!`);
        }
    };

    flashesForm.addEventListener('submit', (e) => simpleFormHandler(e, 'save_flashes'));
    liveTvForm.addEventListener('submit', (e) => simpleFormHandler(e, 'save_livetv'));

    // --- Ad Section Specific Logic ---
    const setupAdPreviews = () => {
        const adSlots = ['main', 'left_sidebar', 'right_sidebar'];

        adSlots.forEach(slot => {
            const fileInput = document.getElementById(`${slot}_ad_image`);
            const previewImg = document.getElementById(`${slot}_ad_preview`);
            const defaultSrc = previewImg.src;

            fileInput.addEventListener('change', () => {
                const file = fileInput.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        previewImg.src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                } else {
                    const adData = siteData.advertisements?.[`${slot}_ad`];
                    previewImg.src = adData?.image_url ? `../${adData.image_url}` : defaultSrc;
                }
            });
        });
    };

    adsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(adsForm);
        formData.append('action', 'save_ads');

        const success = await saveData('save_ads', formData, e.submitter);
        if (success) {
            alert('Advertisements saved successfully!');
        }
    });

    // --- Initial Load ---
    populateCategories();
    fetchData();
    setupAdPreviews();
});
